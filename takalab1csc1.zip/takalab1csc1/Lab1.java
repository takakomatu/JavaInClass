public class Lab1{
    public static void main(String[] args){
        System.out.println("TTTTT   A   K   K   A        K   K  OOO  M   M   A   TTTTT SSSSS U   U");
		System.out.println("  T   AA AA K  K  AA AA      K  K  O   O MM MM AA AA   T   S     U   U");
		System.out.println("  T   AAAAA K K	  AAAAA      K K   O   O M M M AAAAA   T   SSSSS U   U");
		System.out.println("  T   A	  A K  K  A   A      K  K  O   O M M M A   A   T       S  UUU ");
		System.out.println("  T   A	  A K   K A   A	     K   K  OOO  M M M A   A   T   SSSSS   U  ");
   }
}
