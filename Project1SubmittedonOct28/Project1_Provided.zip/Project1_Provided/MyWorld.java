import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/** 
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{
    
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(800, 400, 1); 

    }
    
    /**
     * returns the club selected by the user
     *   @return String containing the label of the Selection box the user has selected. Returns
     *              null if no such box has been selected. 
     */
    public String getClubSelected()
    {
        String ans = null;
        
        // go through all Selection boxes  ...
        for (Selection s: getObjects(Selection.class))
        {
            // if we find the current Selection box has been selected, return it. 
            if (s.isSelected())
                return s.getLabel();
        }
        
        return ans;
    }
}
